/* FIDUNIO single authoritative release version. Update this file for each new release. */
globalThis.FIDUNIO_RELEASE = Object.freeze({
  version: "0.7.3"
});
